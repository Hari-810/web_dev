// script.js - External JavaScript file
function showMessage() {
    document.write("<p>This message is from an external JavaScript file.</p>");
}
