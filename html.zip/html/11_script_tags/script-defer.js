// script-defer.js - External JavaScript file with 'defer'
document.addEventListener("DOMContentLoaded", function () {
    console.log("script-defer.js is executed after HTML content is loaded.");
});
