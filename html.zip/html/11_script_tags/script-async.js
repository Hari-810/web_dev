// script-async.js - External JavaScript file with 'async'
console.log("script-async.js is loaded asynchronously.");
