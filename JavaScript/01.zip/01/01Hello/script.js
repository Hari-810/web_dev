// console.log() is a JavaScript method used for printing or displaying information in the browser console for 
// debugging and logging purposes.

console.log("Hello Guys");



// note to run js file without html install node.js 